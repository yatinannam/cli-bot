from .bot import main
