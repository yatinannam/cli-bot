# CLI Bot

- A simple command-line assistant built with Python.  
- It performs everyday tasks directly from the terminal such as opening websites, managing a to-do list, checking the time, performing calculations, and searching Google.

---

## Features
- Greet the bot with basic commands  
- Show current date and time  
- Open commonly used websites:
  - Google, YouTube, GitHub, LinkedIn, ChatGPT, Wikipedia, Reddit, Gemini, Perplexity  
- Google search from the terminal  
- Calculator for quick math expressions  
- To-Do List with options to:
  - Add tasks  
  - View tasks  
  - Mark tasks as done  
  - Clear all tasks  

---

## Tech Stack:
- Python 3.8+
- Standard Libraries: datetime, os, ast, webbrowser, urllib

---

## Getting Started

### Requirements
- Python 3.8 or above

### Run the bot
```bash
python bot.py
```
---

## Contributions are welcome!

### If you'd like to add new features, improve the code, or fix issues:
- Fork the repository
- Create a new branch (git checkout -b feature-name)
- Commit your changes (git commit -m "Add feature-name")
- Push to your branch (git push origin feature-name)
- Open a Pull Request

---
